# View.io Lexi Embeddings Pipeline

Steps invoked and managed by the View Orchestrator for the purposes of generating embeddings from Lexi search results.
